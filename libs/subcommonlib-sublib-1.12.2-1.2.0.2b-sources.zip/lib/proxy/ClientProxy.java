package lib.proxy;

import net.minecraft.client.Minecraft;
import net.minecraft.entity.player.EntityPlayer;

public class ClientProxy extends ServerProxy{

	@Override
	public Minecraft getMC() {
		return Minecraft.func_71410_x();
	}
	
	@Override
	public EntityPlayer clientPlayer() {
		return getMC().field_71439_g;
	}
}

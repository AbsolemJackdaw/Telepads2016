package lib.proxy;

import net.minecraft.client.Minecraft;
import net.minecraft.entity.player.EntityPlayer;

public class ServerProxy {

	public Minecraft getMC(){return null;}
	public EntityPlayer clientPlayer(){return null;}
}

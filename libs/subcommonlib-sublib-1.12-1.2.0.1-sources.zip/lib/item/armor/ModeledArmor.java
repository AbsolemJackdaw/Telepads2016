package lib.item.armor;

import net.minecraft.client.model.ModelBiped;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.inventory.EntityEquipmentSlot;
import net.minecraft.item.Item;
import net.minecraft.item.ItemArmor;
import net.minecraft.item.ItemStack;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;

public abstract class ModeledArmor extends ItemArmor {

	private ModelBiped armorModel;
	private String tex_loc;

	public ModeledArmor(EntityEquipmentSlot slot, ItemArmor.ArmorMaterial mats, String texture_name) {
		super(mats, 4, slot);

		setRegistryName(texture_name);
		func_77655_b(texture_name);
		tex_loc="armor/"+texture_name;
	}

	public String getModeltextureLocation() {
		return tex_loc;
	}
	/** returns the name of the class from this full set of armor */
	public abstract String armorClassName();

	/** 
	 * if full armor is worn, and the item given in this method is worn in the offhandslot,
	 * then the wielder will get the status of shielded class
	 */
	public abstract Item getLinkedShieldItem();
	
	/**
	 * Called to set the 3D armor model. set models here, not in
	 * getArmorModel(...) !
	 */
	@SideOnly(Side.CLIENT)
	protected abstract void get3DArmorModel(EntityLivingBase entityLiving, ItemStack stack, EntityEquipmentSlot armorSlot);

	@Override 	@SideOnly(Side.CLIENT)
	public ModelBiped getArmorModel(EntityLivingBase entityLiving, ItemStack itemStack, EntityEquipmentSlot armorSlot,
			ModelBiped defaultModel) {

		if (itemStack != null) {
			get3DArmorModel(entityLiving, itemStack, armorSlot);
			if (armorModel != null) {
				armorModel.field_78116_c.field_78806_j = armorSlot == EntityEquipmentSlot.HEAD;
				armorModel.field_178720_f.field_78806_j = armorSlot == EntityEquipmentSlot.HEAD;
				armorModel.field_78115_e.field_78806_j = (armorSlot == EntityEquipmentSlot.CHEST)
						|| (armorSlot == EntityEquipmentSlot.CHEST);
				armorModel.field_178723_h.field_78806_j = armorSlot == EntityEquipmentSlot.CHEST;
				armorModel.field_178724_i.field_78806_j = armorSlot == EntityEquipmentSlot.CHEST;
				armorModel.field_178721_j.field_78806_j = (armorSlot == EntityEquipmentSlot.LEGS)
						|| (armorSlot == EntityEquipmentSlot.FEET);
				armorModel.field_178722_k.field_78806_j = (armorSlot == EntityEquipmentSlot.LEGS)
						|| (armorSlot == EntityEquipmentSlot.FEET);

				armorModel.field_78117_n = defaultModel.field_78117_n;
				armorModel.field_78093_q = defaultModel.field_78093_q;
				armorModel.field_78091_s = defaultModel.field_78091_s;
				armorModel.field_187076_m = defaultModel.field_187076_m;
				armorModel.field_187075_l = defaultModel.field_187075_l;

				return armorModel;
			}
		}
		return null;
	}

	public void setArmorModel(ModelBiped armorModel) {
		//do not add a null check here.
		this.armorModel = armorModel;
	}
}
